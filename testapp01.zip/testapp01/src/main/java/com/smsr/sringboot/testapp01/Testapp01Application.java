package com.smsr.sringboot.testapp01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Testapp01Application {

	public static void main(String[] args) {
		SpringApplication.run(Testapp01Application.class, args);
	}

}
